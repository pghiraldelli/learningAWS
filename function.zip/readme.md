# Lambda-s3

This is the code for the Amazon's [tutorial](https://docs.aws.amazon.com/lambda/latest/dg/with-s3-example.html) of a project using AWS Lambda with Amazon S3.

This tutorial teaches how to:
* Create an execution role
* Creates buckets
* Creates function
* Create a deployment package
* Test your Lambda function
* Configure Amazon S3 to publish events